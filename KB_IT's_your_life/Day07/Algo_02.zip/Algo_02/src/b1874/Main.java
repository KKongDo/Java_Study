package b1874;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Stack;

//스택
public class Main {
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		Stack<Integer> stack=new Stack<Integer>();
		int count=1;
		
		int n=Integer.parseInt(br.readLine());
		int[] nums=new int[n];
		
		for(int i=0; i<n; i++) {
			nums[i]=Integer.parseInt(br.readLine());
		}
		for(int i=0; i<nums.length; i++) {
			int num=nums[i];
			if(num>=count) {
				while(num>=count) {
					stack.push(count++);
					System.out.println('+');
				}
				stack.pop();
				System.out.println('-');
			}
			else {
				int currentN=stack.pop();
				if(currentN>num) {
					System.out.println("No");
				}
				else {
					System.out.println('-');
				}
			}
		}
	}
}
