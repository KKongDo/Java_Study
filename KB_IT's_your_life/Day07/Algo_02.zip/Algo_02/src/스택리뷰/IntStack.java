package 스택리뷰;

import 스택리뷰.IntStack.EmptyIntStackException;
import 스택리뷰.IntStack.OverflowIntStackException;

public class IntStack {
	public class OverflowIntStackException extends RuntimeException {

	}

	public class EmptyIntStackException extends RuntimeException {
		
	}

	private int[] stk;
	private int capacity; //최대저장갯수
	private int ptr=0; //현재 저장할 위치(=현재 저장 갯수)
	
	public IntStack(int len) {
		stk=new int[len];
		capacity=len;
	}

	public IntStack() {
		this(64); // this()는 객체 초기화를 위한 목적이기 때문에 생성자 내에서만 호출이 가능. 일반 메서드에서 호출할 시 컴파일 에러가 발생.
	}

	public boolean push(int i) throws EmptyIntStackException{
		if(ptr==capacity) 
			throw new OverflowIntStackException();
			//return false; //: Exception하기 싫으면
		if(ptr < capacity)
			stk[ptr++]=i;
		return true; //: Exception하기 실흐여
	}

	public int pop() throws EmptyIntStackException{
		if(ptr==0)
			throw new EmptyIntStackException();
		return stk[--ptr];
	}
	
}
