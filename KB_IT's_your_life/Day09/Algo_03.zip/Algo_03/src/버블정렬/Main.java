package 버블정렬;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Main {
	public static void main(String[] args) throws IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("요소수 입력 : ");
		int nx=Integer.parseInt(br.readLine());
		int[] x=new int[nx];
		
		for(int i=0; i<nx; i++) {
			System.out.println("x["+i+"] :");
			x[i]=Integer.parseInt(br.readLine());
		}
		
		BubbleSort(x,nx);
		
		System.out.println("버블정렬한 배열 출력");
		for(int i=0; i<x.length; i++) {
			System.out.print(x[i]+" ");
		}
	}
	//  버블정렬
	private static void BubbleSort(int[] x, int nx) {
		for(int i=0; i<nx; i++) {
			for(int j=nx-1; j>i; j--) {
				if(x[j-1]>x[j])
					swap(x, j-1, j);
			}
		}
		
	}
	//교환메서드
	private static void swap(int[] x, int i, int j) {
		int tmp=x[i];
		x[i]=x[j];
		x[j]=tmp;
	}
}

