package j1158;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

//삽입정렬
public class Main {
	static int N;
	static int[] nums;
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		N=Integer.parseInt(br.readLine());
		
		StringTokenizer st=new StringTokenizer(br.readLine());
		nums=new int[N];
		
		for(int i=0; i<N; i++) {
			nums[i]=Integer.parseInt(st.nextToken());
		}
		insertSort(N);
	}

	private static void insertSort(int n2) {
		for(int i=1; i<N; i++) { //삽입정렬은 두번째 자료부터 비교를 시작한다.
			int j; //인덱스 키값의 바로 앞에 있는 위치 변수
			int tmp=nums[i];
			for(j=i; j>0 && nums[j-1] > tmp; j--) {
				nums[j]=nums[j-1];
			}
			nums[j]=tmp;
			for(int k=0; k<N; k++) {
				System.out.print(nums[k]+" ");
			}
			System.out.println(" ");
		}
	}
}
