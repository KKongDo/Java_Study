package 재귀호출;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("숫자 입력 : ");
		int num=sc.nextInt();
		
		int result=factorial(num);
		
		System.out.print("결과값 : ");
		System.out.println(result);
		
		sc.close();
	}

	private static int factorial(int num) {
		if(num==0)
			return 1;
		return num*factorial(num-1);
	}
}
