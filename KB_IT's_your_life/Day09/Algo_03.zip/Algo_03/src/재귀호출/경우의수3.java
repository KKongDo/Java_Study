package 재귀호출;

//주어진 원소를 이용한 생성가능한 모든 경우의 수
//{1,2,3} -> 111, 112, 113...
//{1,2,3} -> 중복을 허용하지 않으면 123, 132, 213...
//{1,2} 중복사용가능 : 경우의 수 :11, 12, 21, 22
//{1,2} 중복사용X : 경우의 수 : 12, 21

//원소, 답, count, 재귀

public class 경우의수3 { //숫자는 1번씩 사용됨. 두개 숫자만 추출하도록 하는 코드, //{1,2,3} 중복사용X : 경우의 수 : 12, 21
	static int[] arr;
	static int[] result;
	static int n;
	static boolean[] visited; //사용여부 저장
	public static void main(String[] args) {
		arr = new int[]{1,2,3}; // 원소 저장 배열
		result= new int[arr.length-1]; // 답 저장 배월, 배열길이를 n에 맞춰야 함.
		//result= new int[n]; // 답 저장 배월
		n=2; //추출의 갯수 	
		visited=new boolean[arr.length];
		recur(0); // 매개변수로 단계(깊이)를 사용한다.
	}
	
	/** 암기 */
	//DFS, BFS를 위해서 외워야 함.
	private static void recur(int depth) {
		if(depth==n) {//종료조건
			print();
			return;
		}
		//처리코드(깊이의 숫자위치에 i값을 저장)
		for(int i=0; i<arr.length; i++) {
			if(visited[i]==false) {
				result[depth]=arr[i];
				visited[i]=true;
				recur(depth+1);
				visited[i]=false;
			}
		}
	}
	private static void print() {
		for (int i : result) {
			System.out.print(i);
		}
		System.out.println();
	}
}
//결과값
//12
//13
//21
//23
//31
//32