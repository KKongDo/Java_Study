package 재귀호출;

//주어진 원소를 이용한 생성가능한 모든 경우의 수
//{1,2,3} -> 111, 112, 113...
//{1,2,3} -> 중복을 허용하지 않으면 123, 132, 213...
//{1,2} 중복사용가능 : 경우의 수 :11, 12, 21, 22
//{1,2} 중복사용X : 경우의 수 : 12, 21

//원소, 답, count, 재귀

public class 경우의수 {
	static int[] arr;
	static int[] result;
	static int n;
	public static void main(String[] args) {
		arr = new int[]{1,2,3}; // 원소 저장 배열
		result= new int[arr.length]; // 답 저장 배월
		n=3; //추출의 갯수
		recur(0); // 매개변수로 단계(깊이)를 사용한다.
	}
	
	/** 암기 */
	//DFS, BFS를 위해서 외워야 함.
	private static void recur(int depth) {
		if(depth==n) {//종료조건
			print();
			return;
		}
		//처리코드(깊이의 숫자위치에 i값을 저장)
		for(int i=0; i<arr.length; i++) {
			result[depth]=arr[i];
			recur(depth+1);
		}
	}
	private static void print() {
		for (int i : result) {
			System.out.print(i);
		}
		System.out.println();
	}
}
//* 결과값
//111
//112
//113
//121
//122
//123
//131
//132
//133
//211
//212
//213
//221
//222
//223
//231
//232
//233
//311
//312
//313
//321
//322
//323
//331
//332
//333
