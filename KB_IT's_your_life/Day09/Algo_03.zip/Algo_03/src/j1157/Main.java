package j1157;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

//버블정렬
public class Main {
	static int N;
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		N=Integer.parseInt(br.readLine());
		StringTokenizer st=new StringTokenizer(br.readLine());
		int[] nums=new int[N];
		
		for(int i=0; i<N; i++) {
			nums[i]=Integer.parseInt(st.nextToken());
		}
		BubbleSort(N,nums);
	}

	private static void BubbleSort(int n, int[] nums) {
		for(int i=0; i<n-1;i++) {
			for(int j=0; j<n-1; j++) {
				if(nums[j]>nums[j+1]) {
					int tmp=nums[j];
					nums[j]=nums[j+1];
					nums[j+1]=tmp;
				}
			}
			for(int k=0; k<N; k++) {
				System.out.print(nums[k]+" ");
			}
			System.out.println(" ");
		}
	}
}
