package j1146;

import java.util.Scanner;

//선택정렬
public class Main {
	static int[] arr;
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int N=sc.nextInt();
		arr=new int[N];
		
		for(int i=0; i<N; i++) {
			arr[i]=sc.nextInt();
		}
		
		for(int i=0; i<N-1; i++) {
			int min=i;
			for(int j=i+1; j<N; j++) {
				if(arr[j]<arr[min])
					min=j;
			}
			swap(i,min);
			for(int k=0; k<N; k++) {
				System.out.print(arr[k]+" ");
			}
			System.out.println(" ");
		}
		sc.close();
	}
	private static void swap(int i, int min) {
		int tmp=arr[i];
		arr[i]=arr[min];
		arr[min]=tmp;
	}
}
