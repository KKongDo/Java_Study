package j2750;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int k=sc.nextInt(), N=sc.nextInt(),M=sc.nextInt();
		int sum=k*N;
		if(sum>M)
			System.out.println(sum-M);
		else
			System.out.println(0);
		
		sc.close();
	}
}