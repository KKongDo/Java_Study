package b2961;

import java.util.Scanner;
//첫째 줄에 재료의 개수 N(1 ≤ N ≤ 10)이 주어진다. 다음 N개 줄에는 그 재료의 신맛과 쓴맛이 공백으로 구분되어 주어진다. 모든 재료를 사용해서 요리를 만들었을 때, 그 요리의 신맛과 쓴맛은 모두 1,000,000,000보다 작은 양의 정수이다.
//
//1
//3 10
//2
//3 8
//5 8
//4
//1 7
//2 6
//3 8
//4 9
//비트마스크를 이용한 부분집합문제
public class Main_부분집합문제 {
	static int N;
	static int[][] arr;
	static int max;
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		N=sc.nextInt(); //N값 입력
		
		max=Integer.MAX_VALUE; //최소값을 구하기 위한 변수설정
		arr=new int[N][2]; //입력값 저장배열
		
		for(int i=0; i<N; i++) {
			arr[i][0]=sc.nextInt(); //입력하기
			arr[i][1]=sc.nextInt(); //입력하기
		}
		
		bit();//부분집합
		System.out.println(max);
		
		sc.close();
	}

	 static void bit() {
	        for (int i = 1; i < 1 << N; i++) {
	            int mul1=1, sum2=0; //arr[j][0]의 곱과 arr[j][1]의 합을 담는 변수
	        	for (int j = 0; j < N; j++) { 
	                if ((i & 1 << j) != 0) {
	                	mul1*=arr[j][0]; //각 원소들의 합 저장
	                	sum2+=arr[j][1]; //각 원소드릐 곱 저장
	                }
	            }
	            max=Math.min(Math.abs(mul1-sum2),max); // 합과 곱을 빼주어서 최대값과 비교 후 최소값 출력
	        }
	 }
}
