package j9742;
import java.util.Scanner;

public class Main {
	static String input;
	static int num;
	static char[] ch, result;
	static boolean[] visited;
	static int count;
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		while(sc.hasNext()) {
			input=sc.next(); //사용자에게 값입력
			num=sc.nextInt(); //사용자가 입력한 값의 위치
			visited=new boolean[input.length()]; //방문여부
			result = new char[input.length()]; //결과ㄱㅄ 저장배열
			
			ch=input.toCharArray(); // String형식->char배열로
			recur(0); //순열
			
			if(count<num) {
				System.out.println(input+" "+num+" = "+"No permutation");
			}
			count=0;
		}
		sc.close();
	}
	
	private static void recur(int depth) {
		if(depth==input.length()) {
			count++; // 값을 출력할때마다 카운팅
			System.out.println("count :"+count);
			if(count==num) { //카운팅한 수와 값의 위치값이 같으면 출력
				print();
			}
			return;
		}
		for(int i=0; i<input.length() && count!=num; i++) {
			if(visited[i]==false) {
				result[depth]=ch[i]; //입력값을 문자형으로 쪼개져서 저장원소를 가지고 있는 ch변수
				visited[i]=true;
				recur(depth+1);
				visited[i]=false;
			}
		}
	}
	
	private static void print() {
		StringBuilder sb=new StringBuilder();
		for (char num : result) {
			sb.append(num);
		}
		System.out.println(input+" "+num+" = "+sb);
	}
}

