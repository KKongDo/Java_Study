//package b1722;
//
//import java.util.Scanner;
//
//public class Main {
//	public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//		int N=sc.nextInt();
//		int[] nums=new int[N];
//		int[] f=new int[21];
//		boolean[] visited;
//		f[0]=1;
//		
//		for(int i=1; i<=N; i++) {
//			f[i]=f[i-1]*i;
//		}
//		int p=sc.nextInt();
//		if(Q==1) {
//			long k=sc.nextLong();
//			for(int i=0; i<=N; i++) {
//				for(int j=1, cnt=1; j<=N; j++) {
//					if(visited[j]) {
//						continue;
//					}
//					if(k<=cnt*f[N-1]) {
////						k-=
//					}
//				}
//			}
//		}
//		else {
//			
//		}
//		
//		sc.close();
//	}
//}
