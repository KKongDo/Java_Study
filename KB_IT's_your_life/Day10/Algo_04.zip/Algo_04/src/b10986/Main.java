package b10986;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Main {
	public static void main(String[] args) throws IOException {
		Scanner sc=new Scanner(System.in);
		
		int N=sc.nextInt();
		int M=sc.nextInt();
		
		int[] result=new int[N+1];
		int cnt=0;
		
		for(int i=1; i<N+1; i++) {
			result[i]=result[i-1]+sc.nextInt();
		}
		
		for(int i=0; i<N; i++) {
			int sum=0;
			for(int j=N; j>0; j--) {
				sum=result[j]-result[i];
				if(sum%M==0) {
					cnt++;
				}
			}
		}
		System.out.println(cnt);
	}
}
