package j9742;
import java.util.Scanner;

public class Main {
	static String input;
	static int num;
	static char[] ch, result;
	static boolean[] visited;
	static int count;
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		while(sc.hasNext()) {
			input=sc.next();
			num=sc.nextInt();
			visited=new boolean[input.length()];
			result = new char[input.length()];
			
			ch=input.toCharArray();
			recur(0);
			
			if(count<num) {
				System.out.println(input+" "+num+" = "+"No permutation");
			}
			count=0;
		}
		sc.close();
	}
	
	private static void recur(int depth) {
		if(depth==input.length()) {
			count++;
			System.out.println("count :"+count);
			if(count==num) {
				print();
			}
			return;
		}
		for(int i=0; i<input.length() && count!=num; i++) {
			if(visited[i]==false) {
				result[depth]=ch[i];
				visited[i]=true;
				recur(depth+1);
				visited[i]=false;
			}
		}
	}
	
	private static void print() {
		StringBuilder sb=new StringBuilder();
		for (char num : result) {
			sb.append(num);
		}
		System.out.println(input+" "+num+" = "+sb);
	}
}

